# Ultron Assistant — Full Build (Phase 1-6 + HUD)

This is a complete, ready-to-open AndroidIDE project matching your exact create-project specs:
package `com.ultron.assistant`, Gradle 8.12/AGP 8.12, minSdk 29, XML Activity template, Groovy DSL.

**Just extract this zip, open the `Ultron` folder (or whatever you rename it to) as a project in
AIDE via "Open Project", let it sync, then Build → Run.** Everything - Phase 1 through 6, plus
the new HUD/text-chat/Ultron Heart features below - is already wired together.

## What's new in this build (on top of Phase 1-6)

### 1. Full-screen wake-word HUD
Saying the wake trigger (triple-press Volume Up, or shake) no longer just pops a small overlay -
`UltronHudActivity` opens full-screen with a **circular reveal animation from the exact center of
the screen outward** (Android's native `ViewAnimationUtils.createCircularReveal` - this is
literally the "circle khulke fullscreen ho jaye" effect, not an approximation), showing an
original animated red/cyan "arc reactor" style ring graphic (`HudRingsView.java`, pure Canvas -
no image assets, so it's instant to open with zero latency) plus a live conversation log.
Tap the ✕ or press back to close (circular reveal in reverse).

### 2. Type instead of / as well as talk
There's a text input row at the bottom of the HUD (`hud_text_input` + send button). Typed
commands run through the **exact same pipeline** as spoken ones - same `CommandParser` →
`HybridCommandRouter` → `ActionExecutor` → automations → LLM fallback - because both now go
through one shared class, `UltronCore.java`. Anything Ultron can do by voice ("WhatsApp pe Mummy
ko bhejo", "night mode on karo", "Flipkart pe headphones search karo"...) it can now do by typing
the exact same sentence. `MainActivity` also has a **"Talk to Ultron"** button to open the HUD
manually any time, not just on wake word.

### 3. Combined voice + text conversation log
`ConversationBus.java` is a small app-wide pub/sub: every turn (spoken or typed, user or Ultron)
gets posted there once. The HUD's chat log is just a live subscriber, and it replays the last 50
messages on open so opening it mid-conversation isn't a blank screen. This means a command you
spoke from the lock screen shows up in the log the next time you open the HUD to type something,
and vice versa - one unified transcript regardless of input method.

### 4. "Ultron Heart" settings, free-text model field
`SettingsActivity` (now labelled **Ultron Heart** everywhere in the UI) no longer has a fixed
dropdown of models - `model_input` is a plain text field, so you can type **any** OpenRouter
model id (free or paid) and it's written straight to `SettingsManager`'s encrypted storage the
moment you tap Save, same as the API key. No code changes needed to switch models.

### 5. Built for low latency
- The rule-based `CommandParser` (regex, no network) still always runs first; the OpenRouter LLM
  (`OpenRouterClient`/`LlmIntentParser`) is a **fallback only reached when the rules miss** -
  most commands never touch the network at all.
- `HudRingsView` is pure `Canvas` drawing, not decoded bitmaps/GIFs - opens instantly, no asset
  loading delay.
- The LLM call itself uses `temperature=0.2` and `max_tokens=300` - small, fast, deterministic
  JSON responses, not a chatty completion.
- One shared `UltronCore` singleton (lazily built once) - no re-initializing the router/executor
  on every command.

## Everything from Phase 1-6 is still here, unchanged in behaviour
- **Phase 1**: wake triggers, STT/TTS, open-app commands, boot auto-restart
- **Phase 2**: volume/brightness/lock/torch/wifi/bluetooth/DND, overlay (now a lightweight
  fallback only), Ultron Heart (was "Settings")
- **Phase 3**: WhatsApp send, Chrome search (accessibility automation)
- **Phase 4**: AI brain - hybrid rule+LLM routing, 3-turn context memory
- **Phase 5**: Instagram/Telegram/YouTube/YouTube Music/Spotify/Notes/Flipkart/Amazon/Swiggy
  automations, generic app-search fallback for 80+ other apps, reliable call/navigate via intents
- **Phase 6**: custom commands ("night mode on karo"), scheduled actions ("5 minute baad ... karo"),
  battery optimization + autostart helper buttons

## Setup checklist (same as before)
1. Build → Run in AIDE, install the APK.
2. On the main screen, grant in order: Overlay, Accessibility, Device Admin, Write Settings,
   Contacts+Call, then Ignore Battery Optimization and open App Info to enable OEM Autostart
   (ColorOS/MIUI-specific, no public API for this one - manual toggle).
3. Tap **Ultron Heart**, paste your OpenRouter API key from openrouter.ai/keys, type a model id
   (e.g. `meta-llama/llama-3.1-8b-instruct:free`), Save.
4. Tap **Start Ultron**, then either triple-press Volume Up / shake the phone, or just tap
   **Talk to Ultron** to open the HUD directly and try typing a command.

## Phase 7: "Hey Ultron" wake word (openWakeWord, on-device)
- New third wake trigger alongside volume-triple-press and shake: `WakeWordDetector.java` ports
  openWakeWord's streaming pipeline (melspectrogram -> shared embedding -> per-word classifier)
  to Android - openWakeWord itself is Python-only, there's no SDK to just import, so this
  re-implements its inference math directly against the actual model files.
- Two runtimes, because of the specific files this build ships with (all bundled already, in
  `app/src/main/assets/openwakeword/`, see the README.txt in there):
  - `melspectrogram.onnx` + `embedding_model.onnx` -> **ONNX Runtime Mobile**
  - `wakeword.tflite` -> **TensorFlow Lite** - right now this is the stock "Hey Jarvis" model
    (renamed) just to prove the pipeline end-to-end. Say **"Hey Jarvis"** to test it waking up.
    Swap in a custom-trained "hey ultron" `.tflite` later (see the README.txt for the openWakeWord
    Colab training notebook) - nothing else in the code needs to change.
- `UltronService` starts/stops it exactly like the other two triggers. Since Android only lets
  one app cleanly hold the mic, `UltronService.pauseWakeWord()` / `.resumeWakeWord()` are called
  automatically around the HUD's own SpeechRecognizer session (see `UltronHudActivity`) so the
  two never fight over it.
- `adb logcat -s Ultron.WakeWord` after install to confirm model shapes loaded correctly and see
  live scores/triggers.
- Tune `DETECTION_THRESHOLD` (default 0.5) and `DEBOUNCE_MS` (default 2000) at the top of
  `WakeWordDetector.java` if it's too trigger-happy or too sluggish for your environment.

## Phase 9: Telegram Bridge (control Ultron remotely from Telegram)
Talk to Ultron from Telegram exactly like typing in the HUD - same `UltronCore.handle()` pipeline,
same command set (open apps, WhatsApp send, YouTube/Flipkart/etc. search, system toggles, scheduled
actions, LLM fallback for anything else). No separate "Telegram command set" and no raw shell/root
execution path was added - it's the same automation surface as everywhere else in the app.

**Setup:**
1. `Ultron Heart` -> **Telegram Bridge** section -> paste your bot token (from @BotFather) ->
   **Save Token & Start Bridge**.
2. Tap **Generate Remote PIN**. A 4-digit code appears on this screen, valid 5 minutes, one-time use.
3. Open your bot in Telegram, send `/start`, then send that PIN as a plain message.
4. Bot replies "Access granted" - that Telegram chat is now the *only* one that can ever talk to
   Ultron, until you tap **Reset Pairing** and re-pair.

**Security model - read this before using it:**
- The PIN is generated by, and only ever displayed on, this device (`SettingsActivity`,
  `TelegramAuthManager.generatePin()`). Ultron never sends the PIN anywhere - the bot's `/start`
  reply just tells you to go generate one in the app. Reading it requires physical access to your
  unlocked phone, same trust model as a TV/monitor pairing code, not a shared password.
- The **first** chat to send a correct, unexpired PIN gets permanently bound
  (`SettingsManager`'s encrypted `telegram_bound_chat_id`). Every other chat is silently ignored
  from that point on - no reply at all, not even to `/start` - so there's nothing for a stranger
  finding your bot to probe.
- Wrong PIN attempts are rate-limited per chat (5 tries / 10 minutes -> 15 minute cooldown,
  `TelegramAuthManager`) so the 4-digit space can't be brute-forced against an unattended bot.
- `/logout` (or `/unbind`, `/reset`) from the paired chat unpairs it immediately, same as the
  in-app **Reset Pairing** button.
- The bridge only auto-restarts on boot if you hadn't explicitly hit **Stop Bridge**
  (`telegram_bridge_enabled` flag, checked in `BootReceiver`).
- The bot token itself is stored in the same `EncryptedSharedPreferences` as the OpenRouter key
  (`SettingsManager`) - still, treat this repo/APK as sensitive once a real token is in it; don't
  commit or share a build with your live token baked in.

## Known rough edges (same category as before - expect to tighten per your device)
- Phase 5 UI-automation flows (Instagram/Telegram/etc.) use generic content-description/text
  matching since I don't have your exact installed app versions' resource IDs - expect to adjust
  a selector or two after your first real test.
- `genericAppSearch()` is a best-effort fallback, not a guarantee, for apps without a bespoke flow.
- Free OpenRouter models have tight rate limits - a 429 shows as "API limit aa gayi" in the reply,
  not a crash; switch models in Ultron Heart if you hit it often.
- `QUERY_ALL_PACKAGES` is fine for this sideloaded personal APK but is a Play Store policy
  no-go - remove it if you ever publish this.
